package com.example.notesapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: NotesAdapter
    private lateinit var notesList: List<Note>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.notesRecyclerView)
        val fabAddNote: FloatingActionButton = findViewById(R.id.fabAddNote)


        notesList = listOf(
            Note("Note 1", "This is the content of Note 1", "High"),
            Note("Note 2", "This is the content of Note 2", "Medium"),
            Note("Note 3", "This is the content of Note 3", "Low")
        )


        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = NotesAdapter(this, notesList)
        recyclerView.adapter = adapter


        fabAddNote.setOnClickListener {
            val intent = Intent(this@MainActivity, AddNoteActivity::class.java)
            startActivity(intent)
        }
    }
}
