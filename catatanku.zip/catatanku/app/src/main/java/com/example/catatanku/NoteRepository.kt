package com.example.catatanku

object NoteRepository {
    val notes = ArrayList<Note>()
}
