package com.example.catatanku

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

// Model untuk catatan
data class Note(
    val title: String,
    val content: String,
    val priority: String
)

class AddNoteActivity : AppCompatActivity() {

    private lateinit var editTextTitle: EditText
    private lateinit var editTextContent: EditText
    private lateinit var radioGroupPriority: RadioGroup
    private lateinit var buttonSave: MaterialButton


    companion object {
        val notesList: ArrayList<Note> = ArrayList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_note)


        editTextTitle = findViewById(R.id.editTextTitle)
        editTextContent = findViewById(R.id.editTextContent)
        radioGroupPriority = findViewById(R.id.radioGroupPriority)
        buttonSave = findViewById(R.id.buttonSave)


        buttonSave.setOnClickListener {
            val title = editTextTitle.text.toString().trim()
            val content = editTextContent.text.toString().trim()

            if (title.isEmpty() || content.isEmpty()) {
                Toast.makeText(this, "Judul dan Isi Catatan harus diisi!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            val selectedPriorityId = radioGroupPriority.checkedRadioButtonId
            val selectedPriority = findViewById<RadioButton>(selectedPriorityId)?.text.toString()


            val note = Note(title, content, selectedPriority)
            notesList.add(note)


            Toast.makeText(
                this,
                "Catatan Disimpan\nJudul: $title\nIsi: $content\nPrioritas: $selectedPriority",
                Toast.LENGTH_LONG
            ).show()


            finish() // Kembali ke HomeFragment
        }
    }
}
