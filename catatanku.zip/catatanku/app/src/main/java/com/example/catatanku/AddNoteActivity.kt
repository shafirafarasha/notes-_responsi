package com.example.catatanku

import android.os.Bundle
import android.widget.RadioButton
import androidx.appcompat.app.AppCompatActivity
import com.example.catatanku.Note
import com.example.catatanku.NoteRepository
import com.example.catatanku.databinding.ActivityAddNoteBinding

class AddNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddNoteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = getString(R.string.add_note_title)

        binding.btnSave.setOnClickListener {
            val title = binding.etTitle.text.toString()
            val content = binding.etContent.text.toString()
            val selectedId = binding.radioGroupPriority.checkedRadioButtonId

            if (title.isNotEmpty() && content.isNotEmpty() && selectedId != -1) {
                val selectedRadio = findViewById<RadioButton>(selectedId)
                val priority = selectedRadio.text.toString()
                NoteRepository.notes.add(Note(title, content, priority))
                finish()
            }
        }
    }
}
