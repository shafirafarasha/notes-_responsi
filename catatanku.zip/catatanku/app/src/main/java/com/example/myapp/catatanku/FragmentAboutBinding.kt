package com.example.myapp.catatanku

class FragmentAboutBinding {

}
