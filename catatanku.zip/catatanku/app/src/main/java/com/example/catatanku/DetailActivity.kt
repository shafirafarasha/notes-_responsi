package com.example.catatanku

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.catatanku.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = getString(R.string.detail_title)

        val judul = intent.getStringExtra("judul")
        val isi = intent.getStringExtra("isi")
        val prioritas = intent.getStringExtra("prioritas")

        binding.tvTitle.text = judul
        binding.tvContent.text = isi
        binding.tvPriority.text = getString(R.string.priority_label, prioritas)
    }
}
