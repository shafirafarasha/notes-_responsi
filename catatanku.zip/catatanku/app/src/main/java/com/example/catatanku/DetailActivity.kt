package com.example.catatanku

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    private lateinit var tvTitle: TextView
    private lateinit var tvContent: TextView
    private lateinit var tvPriority: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        tvTitle = findViewById(R.id.tvTitle)
        tvContent = findViewById(R.id.tvContent)
        tvPriority = findViewById(R.id.tvPriority)


        val title = intent.getStringExtra("title")
        val content = intent.getStringExtra("content")
        val priority = intent.getStringExtra("priority")


        tvTitle.text = title
        tvContent.text = content
        tvPriority.text = "Prioritas: $priority"
    }
}
