package com.example.catatanku

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.yourapp.DetailActivity
import com.example.yourapp.R
import com.example.yourapp.adapter.NoteAdapter
import com.example.yourapp.model.Note

class HomeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var noteAdapter: NoteAdapter
    private val noteList = ArrayList<Note>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        recyclerView = view.findViewById(R.id.recyclerViewNotes)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())


        noteList.add(Note("Belajar Kotlin", "Mempelajari dasar Kotlin untuk Android", "Tinggi"))
        noteList.add(Note("Belanja", "Beli bahan makanan di supermarket", "Sedang"))
        noteList.add(Note("Olahraga", "Jogging pagi 30 menit", "Rendah"))

        noteAdapter = NoteAdapter(noteList) { note ->

            val intent = Intent(requireContext(), DetailActivity::class.java)
            intent.putExtra("title", note.title)
            intent.putExtra("content", note.content)
            intent.putExtra("priority", note.priority)
            startActivity(intent)
        }

        recyclerView.adapter = noteAdapter

        return view
    }
}
