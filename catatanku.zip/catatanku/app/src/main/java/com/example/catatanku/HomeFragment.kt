package com.example.catatanku

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.catatanku.NoteAdapter
import com.example.catatanku.Note
import com.example.catatanku.NoteRepository
import com.example.catatanku.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: NoteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        setupRecyclerView()
        setupFAB()

        return binding.root
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged()
    }

    private fun setupRecyclerView() {
        adapter = NoteAdapter(NoteRepository.notes) { note ->
            val intent = Intent(requireContext(), DetailActivity::class.java).apply {
                putExtra("judul", note.title)
                putExtra("isi", note.content)
                putExtra("prioritas", note.priority)
            }
            startActivity(intent)
        }

        binding.recyclerViewNotes.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewNotes.adapter = adapter
    }

    private fun setupFAB() {
        binding.fabAddNote.setOnClickListener {
            startActivity(Intent(requireContext(), AddNoteActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
