package com.example.catatanku

data class Note(
    val title: String,
    val content: String,
    val priority: String
)
